/*
    Copyright (c) 2018 Imatest LLC

    This library is free software; you can redistribute it and/or modify it under the terms
    of the GNU Lesser General Public License as published by the Free Software Foundation;
    either version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
    without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License along with this
    library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
    Boston, MA  02111-1307  USA
*/
package redstone.xmlrpc;

import java.net.Authenticator;
import java.net.PasswordAuthentication;

public class XmlRpcAuthenticator extends Authenticator {
	
	public XmlRpcAuthenticator( String username, String password ) 
	{
		this.username = username;
		this.password = password;
	}
	
	

	public PasswordAuthentication getPasswordAuthentication() 
	{
		System.out.println("Something asked for a password!");
		
		System.out.println("Requested for " + getRequestingScheme() + " scheme.");
		
		return (new PasswordAuthentication (this.username, this.password.toCharArray()));
	}
	
	private String username;
	
	private String password;

}
