//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AnimTest.rc
//
#define IDC_MYICON                      2
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDC_OPENIL                      109
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       155
#define IDR_MENU1                       167
#define IDD_DIALOG_ABOUT                168
#define IDC_ABOUT_VENDOR                1001
#define IDC_ABOUT_VER_STRING            1002
#define IDC_ABOUT_VER_NUM               1003
#define IDC_FILTER_EDIT                 1004
#define IDC_FILTER_DESC_TEXT            1005
#define IDC_ERROR1                      1014
#define IDC_ERROR2                      1015
#define IDC_ERROR3                      1016
#define IDC_ERROR4                      1017
#define IDC_ERROR5                      1018
#define IDC_ERROR6                      1019
#define IDC_OPENIL_LINK                 1020
#define ID_FILE_EXIT                    32771
#define ID_HELP_ABOUT                   32772
#define ID_CONVERT_RGB                  32773
#define ID_CONVERT_RGBA                 32774
#define ID_CONVERT_BGR                  32775
#define ID_CONVERT_BGRA                 32776
#define ID_CONVERT_LUMINANCE            32777
#define ID_FILE_LOAD                    32778
#define ID_FILE_SAVE                    32779
#define ID_FILTER_BITFILTER1            32780
#define ID_FILTER_BITFILTER2            32781
#define ID_FILTER_BITFILTER3            32782
#define ID_FILTER_EMBOSS                32783
#define ID_FILTER_NOISE                 32784
#define ID_FILTER_PIXELIZE              32785
#define ID_EFFECTS_FILTERS_SCALE        32786
#define ID_EFFECTS_FILTERS_EDGEDETECT_SOBEL 32787
#define ID_EFFECTS_FILTERS_EDGEDETECT_PREWITT 32788
#define ID_EDIT_UNDO                    32789
#define ID_EDIT_UNDOLEVEL               32790
#define ID_FILTERS_BLUR_AVERAGE         32791
#define ID_FILTERS_BLUR_GAUSSIAN        32792
#define ID_FILTER_GAMMACORRECT          32793
#define ID_FILTER_ALIENIFY              32794
#define ID_FILTER_SHARPEN               32795
#define ID_FILTER_NEGATIVE              32796
#define ID_EFFECTS_FLIP                 32797
#define ID_EFFECTS_MIRROR               32798
#define ID_EFFECTS_COUNTCOLORS          32799
#define ID_EDIT_COPY                    32800
#define ID_EDIT_PASTE                   32801
#define ID_EFFECTS_FILTERS_ROTATE       32802
#define ID_EFFECTS_FILTERS_EDGEDETECT_EMBOSS 32804
#define ID_FILE_OPENURL                 32808
#define ID_CONVERT_PALETTE              32809
#define ID_EDIT_PAUSE                   32810
#define ID_EDIT_RESUME                  32811
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        182
#define _APS_NEXT_COMMAND_VALUE         32812
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
